package models;

public class Like {
    
}
